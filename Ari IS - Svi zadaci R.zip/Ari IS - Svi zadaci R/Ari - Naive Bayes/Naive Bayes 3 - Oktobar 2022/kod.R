

data <- read.csv("rent.csv", stringsAsFactors = F)

str(data)

sum(is.na(data$Rent)) # ima jednu NA vrednost
sum(data$Rent == "-", na.rm = T) # ima dve -
sum(data$Rent == " ", na.rm = T)
sum(data$Rent == "", na.rm = T)

# Rent koristimo za kreiranje nove izlazne varijable, tako da cemo sve redove 
# koji imaju bilo kakvu NA vrednost da uklonimo

# pretvaramo sve crtice u NA vrednost da bismo uklonili preko complete.cases funkcije
data$Rent[data$Rent == "-"] <- NA

# izbacili smo sve redove sa NA za Rent
data <- data[complete.cases(data$Rent),]

# rent je character
class(data$Rent)

# pretvaramo u numeric
data$Rent <- as.numeric(data$Rent)

# uzimamo 85ti percentil
percentil85 <- quantile(data$Rent, 0.85)

# pravimo novu izlaznu varijablu
data$High_Rent <- ifelse(data$Rent > percentil85, yes = "yes", no = "no")

# izbacujemo Rent jer smo je koristili za kreiranje nove izlazne varijable High_Rent
# i pretvaramo High_Rent u faktorsku/kategoricku varijablu
data$Rent <- NULL
data$High_Rent <- as.factor(data$High_Rent)

str(data)

length(unique(data$Posted.On)) # 81 razlicita vrednost, a i datum je u pitanju, tako da
# nece uticati na izlaznu varijablu, uklanjamo
length(unique(data$Floor))  # 480 razlicitih vrednosti, previse, uklanjamo
length(unique(data$Area.Locality)) # 2234 razlicitih vrednosti, previse, uklanjamo
length(unique(data$City)) # 7 razlicitih vrednosti, provericemo da li je relevantna
length(unique(data$Furnishing.Status)) # 3 razlicite vrednosti, provericemo da li je relevantna
length(unique(data$Tenant.Preferred)) # 3 razlicite vrednosti, provericemo da li je relevantna
length(unique(data$Point.of.Contact)) # 3 razlicite vrednosti, provericemo da li je relevantna

data$Posted.On <- NULL
data$Floor <- NULL
data$Area.Locality <- NULL

# proveravamo da li ima NA vrednosti pre nego sto vidimo koje varijable uklanjamo
apply(data, MARGIN = 2, FUN = function(x) sum(is.na(x)))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "-", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == " ", na.rm = T))
# size ima 1 NA vrednost, City takodje, menjamo adekvatnijom

# sredjujemo City
sort(table(data$City))
data$City[is.na(data$City)] <- "Mumbai"

# sredjujemo Size
shapiro.test(data$Size)
# nema normalnu raspodelu, menjamo NA vrednsot u medijanu
medianSize <- median(data$Size, na.rm = T)
data$Size[is.na(data$Size)] <- medianSize

# proveravamo koje vrednosti ima svaka varijabla
table(data$City)
table(data$Furnishing.Status)
table(data$Tenant.Preferred)
table(data$Point.of.Contact)

# pretvaramo sve character koje su potencijalno znacajne za model u factor
data$City <- as.factor(data$City)
data$Furnishing.Status <- as.factor(data$Furnishing.Status)
data$Tenant.Preferred <- as.factor(data$Tenant.Preferred)
data$Point.of.Contact <- as.factor(data$Point.of.Contact)

str(data)

# proveravamo za sve varijable koliko su relevantne
library(ggplot2)
ggplot(data, mapping = aes(x = BHK, fill = High_Rent)) + geom_density(alpha = 0.5)
# sto je veci broj hodnika, spavacih soba i kuhinja, to je veca sansa da bude visoka kirija
ggplot(data, mapping = aes(x = Size, fill = High_Rent)) + geom_density(alpha = 0.5)
# sto je veca povrsina, to je veca sansa da ce biti i veca kirija
ggplot(data, mapping = aes(x = Bathroom, fill = High_Rent)) + geom_density(alpha = 0.5)
# sto je veci broj kupatila, to je veca sansa da kirija bude visoka

ggplot(data, mapping = aes(x = City, fill = High_Rent)) + geom_bar(position = 'dodge')
# u svakom gradu osim Mumbaiu ima daleko vise nekretnina sa niskom kirijom, jedino u 
# Mumbaiu ima skoro 50/50
ggplot(data, mapping = aes(x = Furnishing.Status, fill = High_Rent)) + geom_bar(position = 'dodge')
# najveca sansa da kirija bude visoka je kad je nekretnina opremljena, manja kad je poluopremljena
# a najmanja kad nije opremljena
ggplot(data, mapping = aes(x = Tenant.Preferred, fill = High_Rent)) + geom_bar(position = 'dodge')
# preferirani kupac takodje ima malo znacajnosti u tome da li ce biti visoka kirija ili nece
ggplot(data, mapping = aes(x = Point.of.Contact, fill = High_Rent)) + geom_bar(position = 'dodge')
# ako se agentu treba obratiti za informacije, onda je najveca sansa da cena kirije bude visoka

# sve ove varijable cemo ostaviti jer ce svaka imati utacija na model

str(data)

# proveravamo za BHK, Size i Bathroom da li imaju normalnu raspodelu ili ne
# ako imaju, ostavljamo ih takve kakve jesu, a ako nemaju, moramo da uradimo 
# diskretizaciju da bi dataset bio pogodan za kreiranje Naive Bayes modela

apply(data[,c(1,2,6)], 2, function(x) shapiro.test(x))
# nijedna varijabla nema normalnu raspodelu, sve 3 diskretizujemo

# BHK i Bathroom su integer varijable, pa cemo ih pretvoriti u numeric
# jer discretize funkcija prima numericki dataframe, a Size je vec numeric
# pa ostavljamo je takvu kakva jeste

data$BHK <- as.numeric(data$BHK)
data$Bathroom <- as.numeric(data$Bathroom)

str(data)

to.discretize <- data[,c(1,2,6)]

# install.packages("bnlearn")
library(bnlearn)
discretized <- discretize(data = to.discretize,
                          method = "quantile",
                          breaks = c(2,5,2))
# morao sam 2, 5, 2 da koristim jer drugacije baca gresku, ovo je najbolja diskretizacija
# sto moze da se odradi za ove 3 varijable
summary(discretized)



newData <- as.data.frame(cbind(discretized, data[,c(3:5,7,8)]))
# spojimo dataframe sa diskretizovanim varijablama
# sa varijablama iz originalnog dataframea koje imaju normalnu raspodelu ili su faktorske
# u newData

str(newData)

# sad su nam sve faktor varijable i mozemo da nastavimo dalje

# train i test
library(caret)
set.seed(1010)
indexes <- createDataPartition(newData$High_Rent, p= 0.80, list = F)
train.data <- newData[indexes,]
test.data <- newData[-indexes,]


# install.packages("e1071")
library(e1071)
nb1 <- naiveBayes(High_Rent ~ ., data = train.data)
nb1
# A-priori probability pokazuje prave verovatnoce
# u 85% slucajeva nece biti visoka cena kirije, a u 15% slucajeva ce biti visoka
# za varijable sa normalnom raspodelom pokazuje mean i standardnu devijaciju
# a za diskretizovane verovatnocu za taj interval da dobije odredjenu klasu

nb1.pred <- predict(nb1, newdata = test.data, type = "class")
nb1.pred
# ako umesto type = "class" (ovako dobijamo klase kao predikcije)
# stavimo "raw", onda dobijamo konkretne verovatnoce za high_rent yes ili no
# model ce naravno da izabere vecu verovatnocu kao resenje
# mi cemo kasnije podesiti threshold, odnosno
# birati odredjenu klasu samo ako je verovatnoca veca od vrednosti
# koju smo mi zadali

nb1.cm <- table(true = test.data$High_Rent, predicted = nb1.pred)
nb1.cm

# tacnost ce biti relativno visoka, od 948 observacija, za 864 smo
# tacno predvideli da ce biti visoka cena kirije ili nece
# a precision i recall ce biti solidni

# pravimo funkciju za evaluacione metrike
getEvaluationMetrics <- function(cm) {
  TP <- cm[2,2] 
  TN <- cm[1,1] 
  FP <- cm[1,2] 
  FN <- cm[2,1] 
  
  accuracy <- sum(diag(cm)) / sum(cm) # tacno predvidjene / sve
  precision <- TP / (TP + FP)      # tacno predvidjenje pozitivne / sve predvidjene pozitivne (prva kolona ili druga u zavisnosti od pozitivne klase)
  recall <- TP / (TP + FN)         # tacno predvidjenje pozitivne / prvi ili drugi red u zavisnosti od pozitivne klase
  F1 <- (2 * precision * recall) / (precision + recall)
  
  c(Accuracy = accuracy, 
    Precision = precision, 
    Recall = recall, 
    F1 = F1)
  
}


nb1.eval <- getEvaluationMetrics(nb1.cm)
nb1.eval
nb1.cm

# accuracy = procenat tacnih predikcija, ovde smo od ukupnog broja observacija
# u test setu, sto je 948, tacno predvideli 864, pa nam je tacnost visoka, odnosno 91.14%
# znaci za 763 smo pogodili nije visoka cena kirije
# za 101 smo pogodili da jeste
# za 45 smo rekli da je visoka cena, a zapravo nije
# za 39 smo rekli da nije visoka cena, a zapravo jeste

# precision = udeo onih koje smo predvideli da su pozitivne koje su stvarno pozitivne
# ovde smo od 146 kirija za koje smo rekli da su visoke
# pogodili 101 da jesu, a za 45 smo rekli da jesu
# umesto da nisu, pa nam je precision nesto nizi, odnosno 69.18%

# recall = udeo observacija koje su stvarno pozitivne koje smo predvideli da su pozitivne
# od ukupno 140 visokih kirija smo tacno predvideli 101, a 39 smo pogresili i
# rekli da je niska, umesto visoka, zato nam je i recall 72.14%

# F1 = sluzi za evaluaciju modela kada su precision i recall u balansu, 
# govori koliko je dobar model, ovde nam je vrednost F1 statistike 70.63%,
# sto govori da je nas model solidan

# sad trazimo threshold preko ROC krive
# to je optimalna verovatnoca za specificity i sensitivity
# onda se pravi nova predikcija za ROC krivu, ali TYPE = RAW
# da bismo videli tacne verovatnoce za svaku klasu

nb2.pred.prob <- predict(nb1, newdata = test.data, type = "raw")
nb2.pred.prob



# kreiranje ROC krive, kucaj PROC u cheatsheetu


# install.packages("pROC")
library(pROC)
nb2.roc <- roc(response = as.integer(test.data$High_Rent),
               predictor = nb2.pred.prob[,2],
               levels = c(1,2))
plot.roc(nb2.roc)

# response je izlazna varijabla, ali vrednost treba da bude integer vrednost (NE PISE U CHEATSHEETU !!!!)
# za predictor vrednost dajemo verovatnocu pozitivne klase, odnosno druga kolona
# levels (NE PISE U CHEATSHEETU !!!!!) je uredjen da prvo ide negativna, pa pozitivna klasa
# zato smo mi stavili c(1,2) jer smo prvo zadali poziciju
# negativne klase (no), pa pozitivnu pozitivne (yes)

# sensitivity odgovara recallu (TPR - true positive rate)
# u odnosu na sve kirije koje su visoke (klase koje su pozitivne),
# koji je udeo onih koje smo mi predvideli da su visoke (da jesu pozitivne)

# specificity je isto samo se odnosi na negativnu klasu (FPR - false positive rate)
# u odnosu na sve kirije koje nisu visoke (sve klase koje su negativne),
# koji je udeo onih koje smo mi predvideli da nisu visoke (da jesu negativne)

# da je not_cheap pozitivna klasa 
# onda ide predictor = nb2.pred.prob[,2],levels = c(1,2)

nb2.roc$auc
# sto je AUC - area under the curve veca, to se klasifikator smatra boljim
# ako je 1 onda moze perfektno da razlikuje koja je pozitivna, a koja negativna klasa
# a ako je na primer 0.7 onda ima 70% sanse da razlikuje koja je pozitivna, a koja negativna
# a ako je 0.5 onda ne moze da razlikuje, to je najgora situacija
# 0.9578 odnosno 95.78% je u nasem slucaju (znaci da je izuzetno dobra, sve preko 0.9 se smatraju bas dobrim modelima)
# sada pravimo plot da bismo videli threshold

plot.roc(nb2.roc, print.thres = TRUE, print.thres.best.method = "youden")
# print.thres je TRUE da bi se ispisao najbolji threshold
# youden method bira threshold gde je suma specificity i sensitivity maximalna
# treshold je 0.242, specificity je 0.756, a sensitivity je 0.764

# coords u CHEATSHEET-u, da nadjemo koordinate naseg thresholda
nb2.coords <- coords(nb2.roc, 
                     ret = c("accuracy", "spec", "sens", "thr"), 
                     x = "local maximas")
nb2.coords

# vraca koordinate za nasu nb2.roc 
# ret (return) znaci sta da nam vrati od parametara (ima ih vise, ova 4 su najbitnija)
# local maximas znaci da vrati sve lokalne maximume (tacke na roc krivi)
# transpose uvek stavljamo FALSE zbog prikaza rezultata nb2.coords
# (da ne bude transponovano)

# ovo radimo da bismo izabrali najbolji threshold da maximiziramo
# specificity i sensitivity (ovo se trazi u zadatku, a mogu da vam daju i 
# da nadjete threshold samo za najveci specificity npr.)

# prvi model ima odlican accuracy, ali nizi precision i recall, ako zelimo da povecamo recall
# potrebno je da nadjemo vrednost koja ima visoki specificity i 
# accuracy prilicno visok
# ovo je potrebno izabrati kako zelimo da pobosljamo model

# na slici vidimo da nam je  treshold je 0.147, 
# specificity je 0.847, a sensitivity je 0.979 
# to nam je nb2.coords[4,4] i mozemo to da koristimo te rezultate
# sto smo dobili sa plota
# medjutim mozemo i sami da biramo u zavisnosti od zadatka
# ako trazi da specificity bude sto veci ili sensitivity sto veci
# ovde trazimo threshold gde je njihova suma najveca, zato uzimamo 4,4
prob.threshold <- nb2.coords[4,4]
prob.threshold

# sad radimo predikciju sa novim thresholdom
nb2.pred <- ifelse(test = nb2.pred.prob[,2] >= prob.threshold, 
                   yes = "yes", no = "no")

# stavili smo nb2.pred.prob[,2] jer nam je pozitivna klasa u drugoj koloni
# u yes se upisuje vrednost nase pozitivne klase, u ovom slucaju to je yes
# da je bila pozitivna klasa no onda bi bilo ovako
# nb2.pred <- ifelse(test = nb2.pred.prob[,1] >= prob.threshold, yes = "no", no = "yes")

# pretvaramo u faktor da ne bude vektor karaktera
nb2.pred <- as.factor(nb2.pred)

nb2.cm <- table(true = test.data$High_Rent, predicted = nb2.pred)
nb1.cm
nb2.cm

# recall ce da nam bude izuzetno dobar, ali kao posledica toga ce nam se smanjiti precision

nb2.eval <- getEvaluationMetrics(nb2.cm)
nb1.eval
nb2.eval

data.frame(rbind(nb1.eval, nb2.eval), row.names = c("one", "two"))

# accuracy i precision su nam gori nego u prethodnom modelu
# recall se znacajno povecao, ali F1 statistika se malo smanjila
# dakle nas novi model ima slabiji accuracy, precision i F1 statistiku
# jedino je recall dosta bolji






