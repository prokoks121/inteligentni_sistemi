

data <- read.csv("rent.csv", stringsAsFactors = F)

str(data)

sum(is.na(data$Rent)) # ima jednu NA vrednost
sum(data$Rent == "-", na.rm = T) # ima dve -
sum(data$Rent == " ", na.rm = T)
sum(data$Rent == "", na.rm = T)

# Rent koristimo za kreiranje nove izlazne varijable, tako da cemo sve redove 
# koji imaju bilo kakvu NA vrednost da uklonimo

# pretvaramo sve crtice u NA vrednost da bismo uklonili preko complete.cases funkcije
data$Rent[data$Rent == "-"] <- NA

# izbacili smo sve redove sa NA za Rent
data <- data[complete.cases(data$Rent),]

# rent je character
class(data$Rent)

# pretvaramo u numeric
data$Rent <- as.numeric(data$Rent)

# uzimamo 85ti percentil
percentil85 <- quantile(data$Rent, 0.85)

# pravimo novu izlaznu varijablu
data$High_Rent <- ifelse(data$Rent > percentil85, yes = "yes", no = "no")

# izbacujemo Rent jer smo je koristili za kreiranje nove izlazne varijable High_Rent
# i pretvaramo High_Rent u faktorsku/kategoricku varijablu
data$Rent <- NULL
data$High_Rent <- as.factor(data$High_Rent)

str(data)

# pravimo podskup nekretnina sa manje od 10 kupatila
data <- subset(data, data$Bathroom <= 9)

str(data)

length(unique(data$Posted.On)) # 81 razlicita vrednost, previse, uklanjamo
length(unique(data$Floor))  # 480 razlicitih vrednosti, previse, uklanjamo
length(unique(data$Area.Locality)) # 2233 razlicitih vrednosti, previse, uklanjamo
length(unique(data$City)) # 7 razlicitih vrednosti, provericemo da li je relevantna
length(unique(data$Furnishing.Status)) # 3 razlicite vrednosti, provericemo da li je relevantna
length(unique(data$Tenant.Preferred)) # 3 razlicite vrednosti, provericemo da li je relevantna
length(unique(data$Point.of.Contact)) # 3 razlicite vrednosti, provericemo da li je relevantna

data$Posted.On <- NULL
data$Floor <- NULL
data$Area.Locality <- NULL

# proveravamo da li ima NA vrednosti pre nego sto vidimo koje varijable uklanjamo
apply(data, MARGIN = 2, FUN = function(x) sum(is.na(x)))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "-", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == " ", na.rm = T))
# size ima 1 NA vrednost, City takodje, menjamo adekvatnijom

# sredjujemo City
sort(table(data$City))
data$City[is.na(data$City)] <- "Mumbai"

# sredjujemo Size
shapiro.test(data$Size)
# nema normalnu raspodelu, menjamo NA vrednsot u medijanu
medianSize <- median(data$Size, na.rm = T)
data$Size[is.na(data$Size)] <- medianSize

# proveravamo koje vrednosti ima svaka varijabla
table(data$City)
table(data$Furnishing.Status)
table(data$Tenant.Preferred)
table(data$Point.of.Contact)

# pretvaramo sve character koje su potencijalno znacajne za model u factor
data$City <- as.factor(data$City)
data$Furnishing.Status <- as.factor(data$Furnishing.Status)
data$Tenant.Preferred <- as.factor(data$Tenant.Preferred)
data$Point.of.Contact <- as.factor(data$Point.of.Contact)

str(data)

# proveravamo za sve varijable koliko su relevantne
library(ggplot2)
ggplot(data, mapping = aes(x = BHK, fill = High_Rent)) + geom_density(alpha = 0.5)
# sto je veci broj hodnika, spavacih soba i kuhinja, to je veca sansa da bude visoka kirija
ggplot(data, mapping = aes(x = Size, fill = High_Rent)) + geom_density(alpha = 0.5)
# sto je veca povrsina, to je veca sansa da ce biti i veca kirija
ggplot(data, mapping = aes(x = Bathroom, fill = High_Rent)) + geom_density(alpha = 0.5)
# sto je veci broj kupatila, to je veca sansa da kirija bude visoka

ggplot(data, mapping = aes(x = City, fill = High_Rent)) + geom_bar(position = 'dodge')
# u svakom gradu osim Mumbaiu ima daleko vise nekretnina sa niskom kirijom, jedino u 
# Mumbaiu ima skoro 50/50
ggplot(data, mapping = aes(x = Furnishing.Status, fill = High_Rent)) + geom_bar(position = 'dodge')
# najveca sansa da kirija bude visoka je kad je nekretnina opremljena, manja kad je poluopremljena
# a najmanja kad nije opremljena
ggplot(data, mapping = aes(x = Tenant.Preferred, fill = High_Rent)) + geom_bar(position = 'dodge')
# preferirani kupac takodje ima malo znacajnosti u tome da li ce biti visoka kirija ili nece
ggplot(data, mapping = aes(x = Point.of.Contact, fill = High_Rent)) + geom_bar(position = 'dodge')
# ako se agentu treba obratiti za informacije, onda je najveca sansa da cena kirije bude visoka

# sve ove varijable cemo ostaviti jer ce svaka imati utacija na model

###########################################################################
###########################################################################
###########################################################################
###########################################################################
###########################################################################
###########################################################################

# sredili smo sve podatke, sada kreiramo trening i test set
# createDataPartition u cheatsheetu

# install.packages('caret')
library(caret)
set.seed(1010)
indexes <- createDataPartition(data$High_Rent, p = 0.8, list = FALSE)
train.data <- data[indexes, ] 
test.data <- data[-indexes, ] 

# krosvalidacija
library(e1071)
library(caret)

# radimo 10-fold crossvalidation
numFolds <- trainControl(method = "cv", number = 10) 

# gledamo koja je cp vrednost se pokazala najbolje za nas model
cpGrid <- expand.grid(.cp = seq(from = 0.001, to = 0.05, by = 0.001))

set.seed(1010)
crossvalidation <- train(x = train.data[,-8],
                         y = train.data$High_Rent,
                         method = "rpart", 
                         trControl = numFolds, # numFolds sto smo dobili iznad
                         tuneGrid = cpGrid) # cpGrid sto smo dobili iznad

crossvalidation

# dobili smo da je najbolji cp = 0.004, to cemo iskoristiti za nase drvo
plot(crossvalidation)

# direktno uzimamo cp iz krosvalidacije
cpValue <- crossvalidation$bestTune$cp

library(rpart)
tree <- rpart(High_Rent ~ ., 
               data = train.data,
               method = "class", 
               control = rpart.control(cp = cpValue))

library(rpart.plot)
rpart.plot(tree, extra = 104) # extra 104 pokazuje brojke na odredjen nacin

# sledece sto radimo je pravimo predikciju
tree.pred <- predict(tree, newdata = test.data, type = "class")

# sada pravimo matricu konfuzije

# na glavnoj dijagonali matrice konfuzije nam se nalazi broj tacnih
# predikcija, a na sporednoj broj pogresnih predikcija 
tree.cm <- table(true = test.data$High_Rent, predicted = tree.pred)
tree.cm

# model je odlicno odradio posao, od ukupno 948 observacija u test setu
# tacno je predvideo 893, a 55 pogresio, tako da ce nam tacnost biti visoka, 
# a i ostale metrike solidne

# pravimo funckiju za evaluacione metrike
getEvaluationMetrics <- function(cm) {
  TP <- cm[2,2] 
  TN <- cm[1,1] 
  FP <- cm[1,2] 
  FN <- cm[2,1] 
  
  accuracy <- sum(diag(cm)) / sum(cm) # tacno predvidjene / sve
  precision <- TP / (TP + FP)      # tacno predvidjenje pozitivne / sve predvidjene pozitivne (prva kolona ili druga u zavisnosti od pozitivne klase)
  recall <- TP / (TP + FN)         # tacno predvidjenje pozitivne / prvi ili drugi red u zavisnosti od pozitivne klase
  F1 <- (2 * precision * recall) / (precision + recall)
  
  c(Accuracy = accuracy, 
    Precision = precision, 
    Recall = recall, 
    F1 = F1)
  
}

eval.tree <- getEvaluationMetrics(tree.cm) 
eval.tree
tree.cm

# accuracy = procenat tacnih predikcija, ovde smo od ukupnog broja observacija
# u test setu, sto je 948, tacno predvideli 893 da je visoka ili niska kirija,
# pa nam je tacnost visoka, 94.2%
# za 20 smo rekli da je visoka, a zapravo je niska
# za 35 smo rekli da je niska, a zapravo je visoka

# precision = udeo onih koje smo predvideli da su pozitivne koje su stvarno pozitivne
# ovde smo za 125 nekretnina predvideli da imaju visoku kiriju, 105 smo pogodili, 
# ali smo za 20 rekli da imaju, a zapravo nemaju, pa nam je precision 84%

# recall = udeo observacija koje su stvarno pozitivne koje smo predvideli da su pozitivne
# ovde od ukupno 140 nekretnina sa visokom kirijom, rekli smo da 105 imaju, a za 35 
# smo pogresili i rekli da nemaju, pa nam je recall 75%

# F1 = sluzi za evaluaciju modela kada su precision i recall u balansu, 
# govori koliko je dobar model, u nasem slucaju je 79.25%, pa mozemo da 
# zakljucimo da je solidan







