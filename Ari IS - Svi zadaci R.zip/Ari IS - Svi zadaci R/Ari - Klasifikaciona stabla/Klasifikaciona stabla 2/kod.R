

data <- read.csv("apps.csv", stringsAsFactors = F)

str(data)
summary(data)
# u Ratingu imamo 1474 NA vrednosti, ali to cemo resiti u 4. koraku

# koristimo quantile funkciju za percentile
treciKvartil <- quantile(data$Reviews, 0.75, na.rm = T)

treciKvartil
# treci kvartil nam je 54775.5 i za sve observacije sa brojem recenzija
# veceg od navedenog cemo dati vrednost High_Reviews Yes, a obrnuto No

data$High_Reviews <- ifelse(data$Reviews > treciKvartil, yes = "Yes", no = "No")

# pretvaramo varijablu price u numeric da bismo uradili 2. korak
# takodje moramo da sredimo NA vrednosti prvo jer u starijim verzijama
# R-a ovo nece odmah raditi, a oni su u zadatku naveli drugaciji redosled
sum(is.na(data$Price))
sum(data$Price == "-", na.rm = T)
sum(data$Price == "", na.rm = T)
sum(data$Price == " ", na.rm = T)

data$Price[data$Price == "-"] <- NA
data$Price <- as.numeric(data$Price)

# ostavljamo sve observacije koje imaju cenu manju ili jednaku 350
# ovo ce izbaciti i sve observacije sa NA vrednostima za price
# jer ne znamo njihovu cenu
data <- subset(data, data$Price <= 350)

str(data)


# mozemo i da vidimo koliko razlicitih vrednosti imaju, i vidimo da sve imaju
# veci broj, pa i zbog toga mozemo reci da ih izbacujemo
length(unique(data$App))
length(unique(data$Category))
length(unique(data$Reviews))
length(unique(data$Size))
length(unique(data$Price))
length(unique(data$Genres))
length(unique(data$Last.Updated))
length(unique(data$Current.Ver))
length(unique(data$Android.Ver))

# sada gledamo koje varijable su nam potrebne za model, a koje ne
# App nam nije potrebno za model jer se svako ime aplikacije razlikuje i nece uticati
# na nas rezultat
# Reviews izbacujemo zbog nove varijable High_Reviews
# Size, odnosno velicina aplikacije nema nikakve veze sa kolicinom recenzija
# Price takodje izbacujemo jer je velika vecina aplikacija besplatna, pa nece uticati
# na nas model
# Last.Updated i Current.Ver takodje nemaju nikakve veze sa 
# brojem recenzija za neku aplikaciju

# sledece varijable, pored iznad navedenih razloga, imaju i previse razlicitih vrednosti u odnosu na dataset
# tako da ih necemo pretvoriti u faktorsku, vec izbaciti iz modela jer nisu relevantne
data$App <- NULL
data$Reviews <- NULL
data$Size <- NULL
data$Price <- NULL
data$Last.Updated <- NULL
data$Current.Ver <- NULL

# sledece 3 nemaju visok broj razlicitih vrednosti u odnosu na dataset i mogu da uticu
# na izlaznu varijablu, pa cemo ih pretvoriti u faktorsku i ostaviti kao prediktore
table(data$Category)
table(data$Android.Ver)
table(data$Genres)

# proveravamo nedostajuce vrednosti
apply(data, MARGIN = 2, FUN = function(x) sum(is.na(x)))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "-", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == " ", na.rm = T))
# ovo cemo proveriti opet kad izbacimo NA vrednosti iz Ratinga, da bismo videli
# da nema ostalih tipova nedostajucih vrednosti

# Varijabla Rating ima 1472 NA vrednosti, njih cemo zameniti srednjom vrednoscu
# ili medijanom u zavisnosti od toga kakvu raspodelu varijabla ima

# sledeci shapiro test nam baca gresku sample size must be between 3 and 5000, 
# sto znaci da moramo da posaljemo izmedju 3 i 5000 observacija
shapiro.test(data$Rating)


# kako onda da uradimo shapiro test? 
# poslacemo 5000 RANDOM observacija (samo te kolone) iz dataseta
# za to cemo koristiti funkciju SAMPLE
shapiro.test(sample(data$Rating, size = 5000))
# vidimo da nemamo normalnu raspodelu jer je p-value manje od 0.05
# pa NA vrednosti menjamo medijanom!

medianRating <- median(data$Rating, na.rm = T)
medianRating

data$Rating[is.na(data$Rating)] <- medianRating

str(data)
# vidimo da sve character varijable mozemo da pretvorimo u factor

table(data$Type)
table(data$Content.Rating)
table(data$High_Reviews)

data$Type <- as.factor(data$Type)
data$Content.Rating <- as.factor(data$Content.Rating)
data$High_Reviews <- as.factor(data$High_Reviews)

data$Category <- as.factor(data$Category)
data$Android.Ver <- as.factor(data$Android.Ver)
data$Genres <- as.factor(data$Genres)

str(data)

library(ggplot2)
ggplot(data, mapping = aes(x = Rating, fill = High_Reviews)) + geom_density(alpha = 0.5)
# najveca sansa da ima High_Reviews je kada ima Rating izmedju 4 i 4.8
ggplot(data, mapping = aes(x = Installs, fill = High_Reviews)) + geom_density(alpha = 0.5)
# ne moze bas da se vidi sa slike
ggplot(data, mapping = aes(x = Type, fill = High_Reviews)) + geom_bar(position = 'dodge')
# veca je sansa da ima High_Reviews kada je besplatna aplikacija
ggplot(data, mapping = aes(x = Content.Rating, fill = High_Reviews)) + geom_bar(position = 'dodge')
# najmanja sansa da ima High_Reviews je kada je Content.Rating Everyone
ggplot(data, mapping = aes(x = Category, fill = High_Reviews)) + geom_bar(position = 'dodge')
# sa grafika vidimo da kategorija igrice i te kako utice na HighReviews
ggplot(data, mapping = aes(x = Android.Ver, fill = High_Reviews)) + geom_bar(position = 'dodge')
# android verzija takodje
ggplot(data, mapping = aes(x = Genres, fill = High_Reviews)) + geom_bar(position = 'dodge')
# zanr igrice takodje

# zavrsili smo sa sredjivanjem podataka

# pravimo trening i test setove
library(caret)
set.seed(1010)
indexes <- createDataPartition(data$High_Reviews, p = 0.8, list = FALSE)
train.data <- data[indexes, ] # svi oni koji se nalaze u tih 80%
test.data <- data[-indexes, ] # svi oni koji se NE nalazed u tih 80%, ostalih 20%


# trazimo najbolju vrednost za CP preko krosvalidacije od sa 10 iteracija

library(e1071)
library(caret)
numFolds = trainControl(method = "cv", number = 10) 
cpGrid = expand.grid(.cp = seq(from = 0.001, to = 0.05, by = 0.001)) 

set.seed(1010)
crossvalidation <- train(x = train.data[,-8],
                         y = train.data$High_Reviews,
                         method = "rpart", 
                         trControl = numFolds, # numFolds sto smo dobili iznad
                         tuneGrid = cpGrid) # cpGrid sto smo dobili iznad

crossvalidation


plot(crossvalidation)

# dobili smo da nam je najbolja vrednost za CP 0.005, tu nam je najveci accuracy,
# pa cemo tu vrednost koristiti da napravimo novo drvo
cpValue <- crossvalidation$bestTune$cp

library(rpart)
tree1 <- rpart(High_Reviews ~ ., 
               data = train.data,
               method = "class", 
               control = rpart.control(cp = cpValue))

library(rpart.plot)
rpart.plot(tree1, extra = 104)

# pravimo predikcije sa novim modelom
tree1.pred <- predict(tree1, newdata = test.data, type = "class")

# matrica konfuzije za nov model
tree1.cm <- table(true = test.data$High_Reviews, predicted = tree1.pred)
tree1.cm
# vidimo da ce model da nam bude izuzetno dobar i imati visoke metrike

# Yes nam je pozitivna klasa
getEvaluationMetrics <- function(cm) {
  TP <- cm[2,2]
  TN <- cm[1,1]
  FP <- cm[1,2]
  FN <- cm[2,1]
  
  accuracy = sum(diag(cm))/sum(cm) # tacno predvidjene / sve
  precision <- TP / (TP + FP)      # tacno predvidjenje pozitivne / sve predvidjene pozitivne (prva kolona ili druga u zavisnosti od pozitivne klase)
  recall <- TP / (TP + FN)         # tacno predvidjenje pozitivne / prvi ili drugi red u zavisnosti od pozitivne klase
  F1 <- (2 * precision * recall) / (precision + recall)
  
  c(Accuracy = accuracy, 
    Precision = precision, 
    Recall = recall, 
    F1 = F1)
  
}

eval.tree1 <- getEvaluationMetrics(tree1.cm)
eval.tree1

# accuracy = procenat tacnih predikcija, ovde smo od ukupnog broja observacija
# u test setu, sto je 2163, tacno predvideli 2038, pa nam je tacnost visoka, 0.942
# za 1579 smo rekli da nece da ima visok broj recenzija i pogodili, a za 459 da hoce i pogodili
# za 43 smo rekli da ce da imaju i pogresili, a za 82 da nece i pogresili

# precision = udeo onih koje smo predvideli da su pozitivne koje su stvarno pozitivne
# ovde smo od 502 observacije za koje smo rekli da imaju visok broj recenzija
# za 459 predvideli tacno, a za 43 smo rekli da imaju, a zapravo nemaju, pa nam
# je precision 0.914

# recall = udeo observacija koje su stvarno pozitivne koje smo predvideli da su pozitivne
# ovde smo od ukupno 541 observacije sa visokim brojem recenzija 459 predvideli tacno,
# a za 82 smo rekli da nemaju visok broj recenzija, a zapravo imaju, pa nam 
# je recall nesto manji od precisiona, odnosno 0.85

# F1 = sluzi za evaluaciju modela kada su precision i recall u balansu, 
# govori koliko je dobar model, u nasem slucaju je 0.88, pa mozemo da 
# zakljucimo da jeste dobar



