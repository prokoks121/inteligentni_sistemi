# RADI SAMO SA NUMERICKIM PODACIMA!
# IZLAZNA VARIJABLA JE NUMERICKA!

# da je pisalo da treba da se ucita iz ISLR paketa onda treba
# install.packages('ISLR')

# library(ISLR)
# str(imeDataSeta)
# dataSet <- imeDataSeta

data <- read.csv("Video_Games_Sales_2017_reduced.csv", stringsAsFactors = F)

data <- subset(data, (data$Platform == "PS2" 
                         | data$Platform == "PS3" | data$Platform == "PS4"))

str(data)

# prvo sredjujemo izlaznu varijablu, moramo da obrisemo sve nedostajuce vrednosti
# jer moramo da izvrsimo predvidjanje nad postojecim podacima!
sum(is.na(data$User_Score))
sum(data$User_Score == "", na.rm = T)
sum(data$User_Score == "-", na.rm = T)
sum(data$User_Score == " ", na.rm = T)
table(data$User_Score)

# vidimo da imamo prazne stringove i 'tbd' tako da cemo to pretvoriti u NA vrednosti
# i izbaciti iz naseg dataseta koji koristimo za model!
data$User_Score[data$User_Score == "" | data$User_Score == "tbd"] <- NA

# vraca samo redove koje nemaju NA vrednosti za 13. kolonu, odnosno nasu
# izlaznu varijablu User_Score
data <- data[complete.cases(data$User_Score), ]
# data <- data[complete.cases(data[,13]), ]
# svejedno je sta cete uraditi od ova dva iznad, rade istu stvar

# ubacili su N/A vrednosti takodje (za Year_of_Release npr.)
# to sam video zato sto sam izvrsio table(dataSub$Year_of_Release)...
# ne znam da li kazu na ispitu
apply(data, MARGIN = 2, FUN = function(x) sum(is.na(x)))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "N/A", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == "-", na.rm = T))
apply(data, MARGIN = 2, FUN = function(x) sum(x == " ", na.rm = T))
# varijable Critic_Score, Critic_Count imaju po 174 NA vrednosti

# varijable Developer i Rating imaju 2 i 17 praznih stringova respektivno

# Year_of_release ima 25 N/A vrednosti i Publisher 1

length(unique(data$Name))
length(unique(data$Publisher))
length(unique(data$Developer))

length(unique(data$Rating))
length(unique(data$Platform))
length(unique(data$Genre))

# za linearnu regresiju cemo sve varijable koje nisu numericke i imaju vise 
# od 2 razlicite vrednosti (koje nisu binarne) izbaciti iz daljeg razmatranja

data$Name <- NULL
data$Publisher <- NULL
data$Developer <- NULL
data$Rating <- NULL
data$Platform <- NULL
data$Genre <- NULL

str(data)

# sredicemo year_of_release jer ima N/A vrednosti
# sredicemo critic_score i critic_count jer imaju NA vrednosti

# YEAR OF RELEASE IMA N/A VREDNOSTI
# i trenutno je character varijabla, pretvoricemo je u integer 
# nakon sto pretvorimo sve N/A vrednosti u NA vrednosti
# i odraditi shapiro test da vidimo da li cemo je 
# menjati medijanom ili srednjom vrednoscu

data$Year_of_Release[data$Year_of_Release == "N/A"] <- NA
data$Year_of_Release <- as.integer(data$Year_of_Release)
shapiro.test(data$Year_of_Release)
# nema normalnu, menjamo medijanom

medianYearOfRelease <- median(data$Year_of_Release, na.rm = T)
data$Year_of_Release[is.na(data$Year_of_Release)] <- medianYearOfRelease

# mozete da stavite i redni broj kolone umesto nazive varijabli u sledecoj liniji
apply(data[,c("Critic_Score", "Critic_Count")], 2, FUN = function(x) shapiro.test(x))
# nedostajuce vrednosti numerickih varijabli menjamo srednjom vrednoscu
# ako imaju normalnu raspodelu, a medijanom ako nemaju
# nijedna nema normalnu raspodelu, pa ih menjamo njihovom medijanom

medianCriticScore <- median(data$Critic_Score, na.rm = T)
medianCriticCount <- median(data$Critic_Count, na.rm = T)

data$Critic_Score[is.na(data$Critic_Score)] <- medianCriticScore
data$Critic_Count[is.na(data$Critic_Count)] <- medianCriticCount

data$User_Score <- as.numeric(data$User_Score)

str(data)

# sad su nam sve varijable numericke i izbacili smo nepotrebne
# zavrseno sredjivanje

# sad gledamo korelacije
matrica <- cor(data)
library(corrplot)
corrplot(matrica, method = "number", type = "upper", diag = FALSE)
# jedini koeficijent korelacije koji se moze smatrati od znacaja
# u odnosu na User_Score je Critic_Score = 0.49,
# ostale su sve slabo korelisane
# (nema pravila koji stepen korelacije birate, uvek gledate relativno 
# u odnosu zadatak, mogu i da vam kazu npr. da gledate stepen korelacije
# koji je veci od 0.6)
# ovde vidimo da je jedino relevantno Critic_Score,
# ostali stepeni korelacije su niski
# takodje, kad izaberemo varijable koje su nam relevantne
# moramo da izbegnemo ulazne varijable (ove koje koristimo kao prediktore)
# koje su medjusobno visoko korelisane, onda cemo samo jednu po jednu izbacivati (videcete kad budemo radili VIF)
# to radimo jer kad su medjusobno visoko korelisane, onda ce uticati na model u losem smislu

# pravimo trening i test setove
library(caret)
set.seed(1010)
indexes <- createDataPartition(data$User_Score, p = 0.8, list = FALSE)
train.data <- data[indexes, ]
test.data <- data[-indexes, ]

# pravimo model
# sad za lm uzimamo samo ove koje imaju jacu korelaciju, 
# u ovom slucaju samo Critic_Score
lm1 <- lm(User_Score ~ Critic_Score, data = train.data)
summary(lm1)
# za svako povecanje Critic_Score povecava nam se User_Score za 0.056 poena
# izgled linearne krive y = 3.246993 + 0.056x
# max zvezdica je 3, sto veci broj zvezdica, to je znacajnija predikcija
# intercept znaci kolika bi vrednost bila da su svi prediktori 0 (nije uvek realno)
# residual predstavlja razliku izmedju stvarnih i predvidjenih vrednosti
# i ovde iznosi 1.264
# r-squared znaci da nas model objasnjava 24.42% varijabilieteta zavisne promenljive User_Score
# f-statistika je 431.6, a p-value < 0.05, dakle postoji zavisnost izmedju 
# zavisne promenljive i prediktora i ima smisla razmatrati ovaj nas model

# sad proveravamo multikolinearnost, kolonearnost izmedju prediktora
# ne smemo da uzmemo 2 varijable koje imaju visoku kolinearnost
# OVO RADI AKO IMA 2 ILI VISE VARIJABLI, OVDE IMA SAMO JEDNA, PA NECE RADITI
# install.packages("car")
library(car)
vif(lm1) # variance inflation factor
# ovde imamo samo jednu varijablu, Critic_Score, pa nece raditi !


##############################################
##############################################
# OVAJ MODEL BEZ LIMITA, MOZETE DA 
# GA URADITE DA BISTE VIDELI DA LI JOS NESTO DA UBACITE U MODEL
# ODNOSNO DA LI MOZETE DA NAPRAVITE BOLJI MODEL

# sad pravimo novi model bez limita
lm2 <-  lm(User_Score ~ ., data = train.data)
summary(lm2)
# varijable koje se mogu smatrati od znacaja su 
# YearOfRelease, Critic_Score i Critic_Count
# residual predstavlja razliku izmedju predvidjenih i stvarnih vrednosti
# i ovde iznosi 1.153
# r-squared, nas model opisuje 37.45% varijabilieteta zavisne promenljive
# povecao nam se, sto je logicno, povecava se sto vise prediktora imamo u modelu
# f-statistika je 88.33, a p-value < 0.05, dakle postoji zavisnost izmedju 
# ovih varijabli

# OVDE IMA VISE VARIJABLI PA RADIMO PROVERU MULTIKOLINEARNOSTI
# install.packages("car")
library(car)
vif(lm2)
sqrt(vif(lm2))
sort(sqrt(vif(lm2))) # sortiramo da bude preglednije

# varijable koje imaju sqrt(vif(lm)) veci od 2 su problematicne
# postoji velika kolinearnost izmedju varijabli JP_Sales, Other_Sales, EU_Sales, 
# NA_Sales i Global_Sales
# izbacujemo jednu po jednu, pa gledamo kako se nas model menja

# ova linija koda nam pokazuje koeficijente za nase prediktore
coef(lm2)

# sve osim Global_Sales
lm3 <- lm(User_Score ~ . - (Global_Sales), data = train.data)
summary(lm3)

# eto, izbacivanjem Global_Sales je ostao skoro isti R-squared i isti residual  std. error

sort(sqrt(vif(lm3)))
# sada je sve u redu sto se tice multikolinearnosti

# takodje, mozemo da izbacimo varijable koje se ne smatraju znacajnim, ove bez zvezdica
# i sa jednom zvezdicom i napraviti konacan model

lm5 <- lm(User_Score ~ Year_of_Release + EU_Sales + JP_Sales + Critic_Score + Critic_Count,
           data = train.data)
summary(lm5)
sort(sqrt(vif(lm5)))

# vidimo da su nam ovde sve varijable od znacaja
# residual predstavlja razliku izmedju predvidjenih i stvarnih vrednosti
# i ovde iznosi 1.156
# r-squared, nas model opisuje 36.99% varijabilieteta zavisne promenljive
# smanjio nam se jer imamo manje prediktora nego u prethodnom modelu,
# ali minimalno jer smo izbacili sve varijable koje nam nisu znacajne
# f-statistika je 156.4, a p-value < 0.05, dakle postoji zavisnost izmedju 
# ovih varijabli


#####################################################
#####################################################


# pravimo 4 plota
graphics.off()
par(mfrow = c(1,1)) # da imamo samo 1 red i 1 kolonu za grafove
par(mfrow = c(2,2)) # da imamo 2 reda i 2 kolone za grafove
plot(lm5)

# Prva slika govori koliko je prepostavka o linearnosti zadovoljenja, 
# predikcija se moze smatrati merodavnom ako je crvena linija blizu 
# toga da bude ravna, odnosno tackice su blizu toga da budu jednako rasporedjene
# Residuals su reziduali (razlika izmedju stvarnih i predvidjenih vrednosti)
# a fitted values predvidjene vrednosti 
# ovde se tezi da reziduali budu 0, tako da sto je crvena linija
# bliza 0, to je nas model bolji
# u nasem slucaju pretpostavka linearnosti nije zadovoljavajuca

# druga slika govori o tome da li su reziduali normalno rasporedjeni
# U ovom slucaju nisu jer u pocetku odstupaju u odnosu na isprekidanu liniju

# treca slika proverava da li rezidulali imaju jednake
# varijanse (homoskedasticnost), ukoliko imamo horizontalnu liniju
# bilo gde na plotu, znaci da imaju
# kod nas nije skroz horizontalna, tako da se moze reci da se razlikuju

# cetvrta da li ima observacija sa veoma velikim/malim vrednostima 
# tj. ekstremnim vrednostima, Kukova distanca nam je preko isprekidanih crvenih linija
# ako je neka observacija preko te linije, znaci da imamo ekstremne vrednosti
# ovde nemamo varijable koje su van isprekidane linije
# ako kucate plot(lm3) videcete
# da imamo neke koje su blizu Kukove distance, ali ne preko
# tako da nece praviti problem
# da ih imamo, te vrednosti van Kukove distance ce uticati na model u losem smislu

# nas model ne ispunjava idealne uslove, ali je prihvatljiv

lm5.pred <- predict(lm5, newdata = test.data)
head(lm5.pred)
head(test.data$User_Score)

# mozete da da koristite ovaj ggplot, ali nije neophodno
test.data$User_Score_pred <- lm5.pred

library(ggplot2)
ggplot(test.data) +
    geom_density(aes(x = User_Score, color = 'actual')) +
  geom_density(aes(x = User_Score_pred, color = 'predicted'))

# vidimo da je samo u tacki 7.5 model izuzetno omanuo

# RSS = Residual Sum of Squares
# TSS = Total Sum of Squares
# sve ovo ispod je u cheatsheetu !!!

# residual je razlika izmedju stvarne i predvidjene vrednosti,
# nju sumiramo i kvadriramo da bismo dobili RSS:
RSS <- sum((lm5.pred - test.data$User_Score)^2)

# razlika izmedju vrednosti u testu i srednje vrednosti u trainu,
# nju sumiramo i kvadriramo da bismo dobili TSS
TSS <- sum((mean(train.data$User_Score) - test.data$User_Score)^2)

# ovo je formula za RSQUARED
rsquared <- 1 - RSS / TSS
rsquared
# ukupan objasnjeni varijabilitet je 33.38%


summary(lm5)
# uporedjujemo sa rsquared nad trainom i nad testom i vidimo 
# da je veca na trainu
# ukupan objasnjeni varijabilitet je 33.38%, a na trainu je 36.99%

# RMSE = Root Mean Squared Error, koliku gresku pravimo s predikcijama
# RSS / broj observacija u test setu
RMSE <- sqrt(RSS/nrow(test.data))
RMSE

# pravimo gresku 1.251 poena za izlaznu varijablu User_Score

# OVO NEMA U CHEATSHEETU !
mean(test.data$User_Score) # mean, srednja vrednost nam je 7.14 poena
RMSE/mean(test.data$User_Score)
# greska iznosi 17.53% od srednje vrednosti poena, sto govori da nam je model
# solidan

# NAPOMENA:
# MOZETE DA NAPRAVITE VISE LM - LINEARNIH MODELA I UPOREDJIVATI 
# KOJI JE BOLJI
# POENTA ZADATKA JE KORISCENJE FUNKCIJA, PRAVLJENJE MODELA
# I PISANJE STO VISE KOMENTARA U KONTEKSTU ZADATKA
# DA BI ONI VIDELI DA VI RAZUMETE STA RADITE






