/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuronske;

import java.util.ArrayList;
import java.util.List;
import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSetRow;
import org.neuroph.core.events.LearningEvent;
import org.neuroph.core.events.LearningEventListener;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.BackPropagation;
import org.neuroph.nnet.learning.MomentumBackpropagation;
import org.neuroph.util.data.norm.MaxNormalizer;
import org.neuroph.util.data.norm.Normalizer;

/**
 *
 * @author Ari
 */
public class Main implements LearningEventListener {

    int inputCount = 8;
    int outputCount = 1;
    double[] learRate = {0.2, 0.3, 0.4};
    List<Training> trainings = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        (new Main()).run();
    }

    @Override
    public void handleLearningEvent(LearningEvent event) {
        MomentumBackpropagation bp = (MomentumBackpropagation) event.getSource();
        System.out.println("Iteration: " + bp.getCurrentIteration()
                + " Total network error: " + bp.getTotalNetworkError());
    }

    public void run() {
        String dataSetFile = "diabetes_data.csv";

        DataSet dataSet = DataSet.createFromFile(dataSetFile, inputCount, outputCount, ",");

        Normalizer norm = new MaxNormalizer(dataSet);
        norm.normalize(dataSet);
        dataSet.shuffle();

        DataSet[] trainAndTest = dataSet.split(0.6, 0.4);
        DataSet trainSet = trainAndTest[0];
        DataSet testSet = trainAndTest[1];

        int numOfIterations = 0;
        int numOfTrainings = 0;

        for (double lr : learRate) {
            MultiLayerPerceptron neuralNet = new MultiLayerPerceptron(inputCount, 20, 16, outputCount);

            MomentumBackpropagation learningRule = (MomentumBackpropagation) neuralNet.getLearningRule();
            learningRule.addListener(this);

            learningRule.setLearningRate(lr);
            learningRule.setMaxError(0.07);
            learningRule.setMomentum(0.5);
//            learningRule.setMaxIterations(1000);

            neuralNet.learn(trainSet);

            numOfTrainings++;
            numOfIterations += learningRule.getCurrentIteration();

            double accuracy = evaluateAcc(neuralNet, testSet);
            Training t = new Training(neuralNet, accuracy);
            trainings.add(t);
        }

        System.out.println("Srednja vrednost broja iteracija je: " + (double) numOfIterations / numOfTrainings);
        saveNetWithMaxAccuracy();

    }

    private double evaluateAcc(MultiLayerPerceptron neuralNet, DataSet testSet) {
        MatricaKonfuzije cm = new MatricaKonfuzije(2);

        for (DataSetRow dataSetRow : testSet) {
            neuralNet.setInput(dataSetRow.getInput());
            neuralNet.calculate();

            int actual = (int) Math.round(dataSetRow.getDesiredOutput()[0]);
            int predicted = (int) Math.round(neuralNet.getOutput()[0]);

            cm.incrementMatrixElement(actual, predicted);
        }

        cm.ispisi();

        double accuracy = (double) (cm.getTruePositive(0) + cm.getTrueNegative(0)) / cm.total;

        System.out.println("Moj accuracy: " + accuracy);
        return accuracy;
    }

    private void saveNetWithMaxAccuracy() {
        Training maxTraining = trainings.get(0);
        for (Training training : trainings) {
            if (training.getAccuracy() > maxTraining.getAccuracy()) {
                maxTraining = training;
            }
        }
        maxTraining.getNeuralNet().save("nn.nnet");
    }

}
