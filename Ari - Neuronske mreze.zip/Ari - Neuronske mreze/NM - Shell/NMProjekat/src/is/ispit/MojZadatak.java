package is.ispit;


import org.neuroph.core.data.DataSet;
import org.neuroph.exam.NeurophExam;
import org.neuroph.nnet.MultiLayerPerceptron;


public class MojZadatak implements NeurophExam {

            
    /**
     * U ovoj metodi pozivati sve metode koje cete implementirati iz NeurophExam interfejsa
     */
    private void run() {        
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
    @Override
    public DataSet loadDataSet() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public DataSet preprocessDataSet(DataSet ds) {
        throw new UnsupportedOperationException("Not supported yet"); 
    }

    @Override
    public DataSet[] trainTestSplit(DataSet ds) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public MultiLayerPerceptron createNeuralNetwork() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public MultiLayerPerceptron trainNeuralNetwork(MultiLayerPerceptron mlp, DataSet ds) {
        throw new UnsupportedOperationException("Not supported yet.");  
    }

    @Override
    public void evaluate(MultiLayerPerceptron mlp, DataSet ds) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void saveBestNetwork() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    public static void main(String[] args) {
        new MojZadatak().run();
    }


}
